=== Updateable Plugin ===
Contributors:      The University of Tennessee, Knoxville
Tags:              test
Tested up to:      6.7
Stable tag:        1.0.4
License:           GPL-2.0-or-later
License URI:       https://www.gnu.org/licenses/gpl-2.0.html

A simple plugin for testing updates.

== Description ==

Testing the plugin update checker functionality with a simple plugin the shows an admin menu

== Installation ==

This section describes how to install the plugin and get it working.

e.g.

1. Upload the plugin files to the `/wp-content/plugins/home-hero-plugin` directory, or install the plugin through the WordPress plugins screen directly.
1. Activate the plugin through the 'Plugins' screen in WordPress

== Changelog ==

= 1.0.4 =
* Add readme.txt
* Update heading

= 1.0.3 =
* Update Heading
* Bump Version Number

= 1.0.0 =
* Initial Release
